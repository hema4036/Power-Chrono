#include"types.h"
#ifndef DELAY_H
#define DELAY_H

//function prototypes
void delay_us(u32);
void delay_ms(u32);
void delay_s(u32);

#endif //DELAY_H
